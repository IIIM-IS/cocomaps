﻿import cmsdk2

def PsyCrank(apilink):
    api = cmsdk2.PsyAPI.fromPython(apilink);
    name = api.getModuleName();
    print("Module name: %s" % name)
    key = api.getParameterInt("Key");
    while (api.shouldContinue()):
        msg = api.waitForNewMessage(20)
        if msg != None:
            mykey = msg.getInt("MyKey")
            if mykey == 0:
                mykey = key
            triggerName = api.getCurrentTriggerName()
            api.logPrint(1, "Got Key: " + str(mykey))
            outMsg = cmsdk2.DataMessage()
            outMsg.setInt("MyKey", mykey + 1)
            api.postOutputMessage("Output", outMsg)

outMsg = cmsdk2.DataMessage()
outMsg.setInt("MyKey", 1)
print(outMsg.toJSON())
