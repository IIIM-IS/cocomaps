﻿#!/usr/bin/env python

import signal
import cmsdk2
import datetime
import roslib
import rospy
import threading
import time
import cv2
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
import datetime

from cmros import utils
from cmros import sensors
from cmros import navigation
from cmros import blobdetector

def handler(signum, frame):
	print "Execution terminated..."
	exit(0)

signal.signal(signal.SIGINT, handler)

global api
api = None

def postEvent(name, data):
	global api
	if (api is not None):
		msg = cmsdk2.DataMessage()
		utils.addObjectToMsg(data, msg, "")
		api.postOutputMessage(name, msg)

def postMessage(name, msg):
	global api
	if (api is not None):
		api.postOutputMessage("IR", imgMsg)
			
def thresholded_image(image):
    # convert image to hsv
    image_hsv = cv.CreateImage(cv.GetSize(image), image.depth, 3)
    cv.CvtColor(image, image_hsv, cv.CV_BGR2HSV)
    # threshold the image
    image_threshed = cv.CreateImage(cv.GetSize(image), image.depth, 1)
    cv.InRangeS(image_hsv, MIN_THRESH, MAX_THRESH, image_threshed)
    return image_threshed
			
			
def runCrankSystem():
	rospy.init_node("robot_status")
	global api
	try:
		laptop = sensors.netbook_battery()
		base = sensors.kobuki_battery()
		buttons = sensors.kobuki_button(postEvent)
		colorcam = sensors.robot_camera_color()
		usbcam = sensors.robot_camera_usb()
		depthcam = sensors.robot_camera_depth()
		registeredcam = sensors.robot_camera_registered()
		map = navigation.robot_map(api)
		control = navigation.NavControl()
	except rospy.ROSInterruptException:
		rospy.loginfo("exception")
		print("--------------------------------")
		return

	useBlobDetector = False
	initpose_x = initpose_y = initpose_oz = initpose_ow = 0
		
	if (api is not None):
		initpose_x = api.getParameterFloat("initpose_x")
		initpose_y = api.getParameterFloat("initpose_y")
		initpose_oz = api.getParameterFloat("initpose_oz")
		initpose_ow = api.getParameterFloat("initpose_ow")
		useBlobDetector = api.getParameterAsBool("useblobdetector")
			
	control.controlCommand("Ready")

	lastImagePost = datetime.datetime.now() - datetime.timedelta(milliseconds=1000)
	
	while True:
		if (api is not None):
			n = 0;
			while (n < 10):
				triggerMsg = api.waitForNewMessage(20)
				if (triggerMsg is not None):
					name = api.getCurrentTriggerName()
					print("Got trigger: " + name)
					if name == 'InitPose':
						x = triggerMsg.getFloat("X")
						y = triggerMsg.getFloat("Y")
						oz = triggerMsg.getFloat("OZ")
						ow = triggerMsg.getFloat("OW")
						map.mapInitPose(x,y,oz,ow);
					elif name == 'NavigateCommand':
						if not map.currentlynavigating:
							x = triggerMsg.getAsFloat("X")
							y = triggerMsg.getAsFloat("Y")
							oz = triggerMsg.getAsFloat("OZ")
							ow = triggerMsg.getAsFloat("OW")
							map.mapNavigateTo(x,y,oz,ow);
						else:
							api.postOutputMessage("NavigateAlreadyActive")
					else:
						control.controlCommand(name)
				else:
					time.sleep(0.01)
				control.controlLoop()
				n += 1
			#triggerMsg = api.waitForNewMessage(0)
			msg = cmsdk2.DataMessage()
		else:
			time.sleep(1)
		
		if (api is not None):
			core = base.getData()
			if (core is not None):
				if (core.charger == 6 or core.charger == 2):
					if (initpose_x != 0 and initpose_y != 0 and initpose_oz != 0 and initpose_ow != 0):
						print "*** Robot is currently docked, initialising pose ***"
						map.mapInitPose(initpose_x, initpose_y, initpose_oz, initpose_ow)
						initpose_x = initpose_y = initpose_oz = initpose_ow = 0
						control.moveOutOfDock(0.5)
		
			utils.addObjectToMsg(laptop.getData(), msg, "laptop")
			utils.addObjectToMsg(base.getData(), msg, "core")
			utils.addObjectToMsg(map.getMetaData(), msg, "map_data")
			utils.addObjectToMsg(map.getOdomData(), msg, "map_odom")
			utils.addObjectToMsg(map.getPoseData(), msg, "map_pose")
			api.postOutputMessage("Status", msg)

			elapsed = datetime.datetime.now() - lastImagePost
			if (elapsed.total_seconds >= 1):
			
				data = usbcam.getColorData()
				if (data is not None):
					imgMsg = cmsdk2.DataMessage()
					data.addToMsg(imgMsg)
					api.postOutputMessage("USB", imgMsg)
				colorData = colorcam.getColorData()
				if (colorData is not None):
					imgMsg = cmsdk2.DataMessage()
					colorData.addToMsg(imgMsg)
					api.postOutputMessage("Color", imgMsg)
				data = colorcam.getIRData()
				if (data is not None):
					imgMsg = cmsdk2.DataMessage()
					data.addToMsg(imgMsg)
					api.postOutputMessage("IR", imgMsg)
				data = depthcam.getData()
				if (data is not None):
					imgMsg = cmsdk2.DataMessage()
					data.addToMsg(imgMsg)
					api.postOutputMessage("Depth", imgMsg)
				data = registeredcam.getData()
				if (data is not None):
					imgMsg = cmsdk2.DataMessage()
					data.addToMsg(imgMsg)
					api.postOutputMessage("Registered", imgMsg)
				data = map.getData()
				if (data is not None):
					imgMsg = cmsdk2.DataMessage()
					data.addToMsg(imgMsg)
					api.postOutputMessage("Map", imgMsg)

		# run blob detection
		if (useBlobDetector and colorData is not None):
			#print "Processing color image for blobs..."
			lowerColor = (140,40,40)  #130,150,80 (BGR)
			upperColor = (255,120,120) #250,250,120
			cv_image = CvBridge().imgmsg_to_cv2(colorData.image, colorData.image.encoding)
			params = cv2.SimpleBlobDetector_Params()
			params.minThreshold = 10;    # the graylevel of images
			params.maxThreshold = 255;
			#params.filterByArea = False
			#params.minArea = 20000 #1500
			#params.maxArea = 40000 #1500
			# Filter by Circularity
			params.filterByCircularity = True
			params.minCircularity = 0.75
			#params.maxCircularity = 0.9
			# Filter by Convexity
			params.filterByConvexity = False
			#params.minConvexity = 0.2 #0.87
			# Filter by Inertia
			params.filterByInertia = True
			params.minInertiaRatio = 0.6
			
			ver = (cv2.__version__).split('.')
			if int(ver[0]) < 3 :
				detector = cv2.SimpleBlobDetector(params)
			else :
				detector = cv2.SimpleBlobDetector_create(params)
				
			mask = cv2.inRange(cv_image, lowerColor, upperColor)
			im=cv2.bitwise_not(mask)
			img = cv2.medianBlur(im,5)
			cv2.imwrite('blobs.png',img)

			keypoints = detector.detect(img)
			if (api is not None):
				for kp in keypoints:
					print "Blob detected: (%d, %d) size=%.1f resp=%.1f" % (kp.pt[0], kp.pt[1], kp.size, kp.response)
					blobMsg = cmsdk2.DataMessage()
					blobMsg.setFloat("blobsize", kp.size)
					blobMsg.setFloat("x", kp.pt[0])
					blobMsg.setFloat("y", kp.pt[1])
					api.postOutputMessage("Blob", blobMsg)
			else:
				for kp in keypoints:
					print "Blob detected: (%d, %d) size=%.1f resp=%.1f" % (kp.pt[0], kp.pt[1], kp.size, kp.response)

if __name__ == '__main__':
	runCrankSystem()

def PsyCrank(apilink):
	global api
	api = cmsdk2.PsyAPI.fromPython(apilink);
	name = api.getModuleName();
	api.logPrint(1, "Module name: " + name)
	runCrankSystem()
