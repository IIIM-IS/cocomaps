import cv2

def detectblobs(image, lowerColor, upperColor, minArea):
	# Setup SimpleBlobDetector parameters.
	params = cv2.SimpleBlobDetector_Params()
 
	# # Change thresholds
	# params.minThreshold = 10;
	# params.maxThreshold = 200;
	 
	# # Filter by Area.
	# params.filterByArea = True
	# params.minArea = minArea #1500
	 
	# # Filter by Circularity
	# params.filterByCircularity = True
	# params.minCircularity = 0.1
	# #params.maxCircularity = 0.9
	 
	# # Filter by Convexity
	# params.filterByConvexity = True
	# params.minConvexity = 0.1 #0.87
	 
	# # Filter by Inertia
	# params.filterByInertia = True
	# params.minInertiaRatio = 0.1
	 
	# Create a detector with the parameters
	ver = (cv2.__version__).split('.')
	if int(ver[0]) < 3 :
		detector = cv2.SimpleBlobDetector(params)
	else :
		detector = cv2.SimpleBlobDetector_create(params)
		
	mask = cv2.inRange(image, lowerColor, upperColor)
	keypoints = detector.detect(mask)
	for kp in keypoints:
		print "(%d, %d) size=%.1f resp=%.1f" % (kp.pt[0], kp.pt[1], kp.size, kp.response)
		#cv2.circle(image, (int(kp.pt[0]), int(kp.pt[1])), int(kp.size), (0, 0, 255))
		
	# lower = (10,150,10)  #130,150,80 (BGR)
	# upper = (150,250,150) #250,250,120
	# mask = cv2.inRange(image, lower, upper)		
	# keypoints = detector.detect(mask)
	# print "---Green---"
	# for kp in keypoints:
		# print "(%d, %d) size=%.1f resp=%.1f" % (kp.pt[0], kp.pt[1], kp.size, kp.response)
		# #cv2.circle(image, (int(kp.pt[0]), int(kp.pt[1])), int(kp.size), (0, 0, 255))
		
	# lower = (150,10,10)  #130,150,80 (BGR)
	# upper = (250,150,150) #250,250,120
	# mask = cv2.inRange(image, lower, upper)		
	# keypoints = detector.detect(mask)
	# print "---Blue---"
	# for kp in keypoints:
		# print "(%d, %d) size=%.1f resp=%.1f" % (kp.pt[0], kp.pt[1], kp.size, kp.response)
		# #cv2.circle(image, (int(kp.pt[0]), int(kp.pt[1])), int(kp.size), (0, 0, 255))
