import numpy as np

class RawImage():
	def __init__(self):
		self.image = None
		self.serial = 0
		self.lastRead = 0
	def setData(self, data):
		if (data is None):
			return
		self.image = data
		self.serial += 1
	def getData(self, force = False):
		if (self.lastRead < self.serial or force):
			self.lastRead = self.serial
			return self
		else:
			return None
	def addToMsg(self, msg):
		msg.setSerial(self.serial)
		msg.setData("Image", self.image.data, int(len(self.image.data)))
		msg.setInt("width", self.image.width);
		msg.setInt("height", self.image.height);
		msg.setInt("step", self.image.step);
		msg.setString("encoding", self.image.encoding);

class RawMap():
	def __init__(self):
		self.map = None
		self.serial = 0
		self.lastRead = 0
	def setData(self, data):
		if (data is None):
			return
		self.map = data
		self.serial += 1
	def getData(self, force = False):
		if (self.lastRead < self.serial or force):
			self.lastRead = self.serial
			return self
		else:
			return None
	def addToMsg(self, msg):
		msg.setSerial(self.serial)
		c_array = np.ascontiguousarray(self.map.data, dtype='int8')
		mybytes = c_array.tostring()
		msg.setData("Image", mybytes, int(len(mybytes)))
		msg.setInt("width", self.map.info.width);
		msg.setInt("height", self.map.info.height);
		msg.setInt("step", self.map.info.width);
		msg.setString("encoding", "8PC1");


def addObjectToMsg(obj, msg, title, n = 0):
	if (n > 4):
		return
	if (obj is None):
		return
	if (isinstance(obj, RawImage)):
		return obj.addToMsg(msg)
	for attr in dir(obj):
		if not attr.startswith('_') and attr.find("func_") == -1 and attr.find("_func") == -1 and attr.find("self") == -1 and not attr.isupper() and (attr.find('serialize') == -1) and (attr != 'header'):
			var = getattr(obj, attr)
			if type(var) == type(True):
				msg.setInt(title + "_" + attr, int(var))
				#print attr + " = (bool) " + str(int(var))
			elif isinstance( var, ( int, long ) ):
				msg.setInt(title + "_" + attr, var)
				#print attr + " = (int) " + str(var)
			elif isinstance( var, ( float ) ):
				msg.setDouble(title + "_" + attr, var)
				#print attr + " = (float) " + str(var)
			elif hasattr(var, '__class__'):
				addObjectToMsg(var, msg, title + "_" + attr, n + 1)
			else:
				msg.setString(title + "_" + attr, str(var))
				#print attr + " = ("+type(var)+") " + str(var)
