import cmsdk2
import rospy
import threading
import ctypes
import tf
from nav_msgs.msg import MapMetaData
from nav_msgs.msg import OccupancyGrid
from nav_msgs.msg import Odometry
from actionlib_msgs.msg import GoalStatusArray
from ctypes import *
from geometry_msgs.msg import Twist
from geometry_msgs.msg import PoseWithCovarianceStamped
from geometry_msgs.msg import PoseStamped
from cmros import utils
import datetime

class NavControl():
	def __init__(self):
		self.lock = threading.Lock()
		self.map_data = None
		self.map_data_count = 0
		self.map_metadata = None
		self.map_metadata_count = 0
		self.speed = 0.2
		self.turn = 1
		self.count = 0
		self.lastRead = -1
		self.status = 0   # 0 means not currently navigating
		self.acc = 0.02
		self.maxSteps = 8
		self.target_speed = 0
		self.target_turn = 0
		self.control_speed = 0
		self.control_turn = 0
		
		self.navPub = rospy.Publisher('/cmd_vel_mux/input/teleop', Twist, queue_size=5)

		self.moveBindings = {
			'CommandMoveForward':(1,0),
			'CommandMoveBackward':(-1,0),
			'CommandTurnLeft':(0,1),
			'CommandTurnRight':(0,-1),
			'CommandMoveForwardLeft':(1,1),
			'CommandMoveForwardRight':(1,-1),
			'CommandMoveBackwardLeft':(-1,-1),
			'CommandMoveBackwardRight':(-1,1),
			}

		self.speedBindings={
			'q':(1.1,1.1),
			'z':(.9,.9),
			'w':(1.1,1),
			'x':(.9,1),
			'e':(1,1.1),
			'c':(1,.9),
			} 
		
	def statustext(self, text):
		return text + " [speed: %s  turn: %s]  target [speed: %s  turn: %s]" % (self.control_speed, self.control_turn, self.target_speed, self.target_turn)
		
	def controlLoop(self):
		if (self.status == 0):
			# not currently navigating
			return
		try:
			self.count = self.count + 1
			if self.count > self.maxSteps:
				self.target_speed = 0
				self.target_turn = 0
				
			if self.target_speed > self.control_speed:
				self.control_speed = min( self.target_speed, self.control_speed + self.acc )
			elif self.target_speed < self.control_speed:
				self.control_speed = max( self.target_speed, self.control_speed - self.acc )
			else:
				self.control_speed = self.target_speed

			if self.target_turn > self.control_turn:
				self.control_turn = min( self.target_turn, self.control_turn + 0.1 )
			elif self.target_turn < self.control_turn:
				self.control_turn = max( self.target_turn, self.control_turn - 0.1 )
			else:
				self.control_turn = self.target_turn
				
			twist = Twist()
			twist.linear.x = self.control_speed; twist.linear.y = 0; twist.linear.z = 0
			twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = self.control_turn
			self.navPub.publish(twist)
			#print("Published: " + str(twist))
			if (self.control_speed != 0 or self.control_turn != 0):
				print self.statustext("Robot navigating: ")
				self.status = 1
			else:
				print self.statustext("Robot navigation finished")
				self.status = 0

			#print("loop: {0}".format(count))
			#print("target: vx: {0}, wz: {1}".format(target_speed, target_turn))
			#print("publihsed: vx: {0}, wz: {1}".format(twist.linear.x, twist.angular.z))

		except Exception as inst:
			print type(inst)     # the exception instance
			print inst.args      # arguments stored in .args
		#finally:
			#twist = Twist()
			#twist.linear.x = 0; twist.linear.y = 0; twist.linear.z = 0
			#twist.angular.x = 0; twist.angular.y = 0; twist.angular.z = 0
			#navPub.publish(twist)
			#print("Published: " + str(twist))
		

	def moveOutOfDock(self, distance):
		self.acc = 0.02
		self.maxSteps = 20
		self.count = 0
		self.target_speed = -1
		self.target_turn = 0
		self.status = 1
		
	def controlCommand(self, key):
		self.maxSteps = 5
		self.acc = 0.02
		x = 0
		th = 0
		try:
			if key in self.moveBindings.keys():
				x = self.moveBindings[key][0]
				th = self.moveBindings[key][1]
				self.count = 0
				#print(key)
			elif key in self.speedBindings.keys():
				self.speed = self.speed * self.speedBindings[key][0]
				self.turn = self.turn * self.speedBindings[key][1]
				self.count = 0
				#if (status == 14):
				#	print msg
				#self.status = (self.status + 1) % 15
			elif key == ' ' or key == 'k' or key == 'Stop' :
				x = 0
				th = 0
				self.control_speed = 0
				self.control_turn = 0

			self.target_speed = self.speed * x
			self.target_turn = self.turn * th
			self.status = 1
			#print vels(target_speed,target_turn)

		except Exception as inst:
			print type(inst)     # the exception instance
			print inst.args      # arguments stored in .args

class location_data():
	def __init__(self):
		self.x = 0;
		self.y = 0;
		self.z = 0;
		self.pitch = 0;
		self.roll = 0;
		self.yaw = 0;
		self.odom = None

class NavigationStatus():
	def __init__(self,status):
		self.data = status
		self.created = datetime.datetime.now()
		self.lastUpdated = datetime.datetime.now()
		self.complete = False
		
class robot_map():
	def __init__(self, api = None):
		self.lock = threading.Lock()
		self.api = api
		self.data = utils.RawMap()
		self.count = 0
		self.metadata = None
		self.metadata_count = 0
		self.metadata_lastRead = 0
		self.odomdata = None
		self.odomdata_count = 0
		self.odomdata_lastRead = 0
		self.posedata = None
		self.posedata_count = 0
		self.posedata_lastRead = 0
		self.navstatusdata = None
		self.navstatusdata_count = 0
		self.navstatusdata_lastRead = 0
		self.navtimeout = 60
		self.currentlynavigating = False
		self.locdata = location_data()
		self.navigationTasks = {}
		rospy.Subscriber("/map",OccupancyGrid,self.MapCallback)
		rospy.Subscriber("/map_metadata",MapMetaData,self.MapMetaDataCallback)
		rospy.Subscriber("/odom",Odometry,self.OdomCallback)
		rospy.Subscriber("/amcl_pose",PoseWithCovarianceStamped,self.PoseCallback)
		rospy.Subscriber("move_base/status",GoalStatusArray,self.NavigationCallback)
		self.mapInitPub = rospy.Publisher('/initialpose', PoseWithCovarianceStamped, queue_size=10)
		self.mapNavigatePub = rospy.Publisher('move_base_simple/goal', PoseStamped, queue_size=10)
	def getData(self, force = False):
		self.lock.acquire()
		data = self.data.getData()
		self.lock.release()
		return data
	def getCount(self):
		self.lock.acquire()
		count = self.data.getCount()
		self.lock.release()
		return count
	def getMetaData(self, force = False):
		self.lock.acquire()
		#if (self.metadata_lastRead < self.metadata_count):
		data = self.metadata
		#else:
		#	data = None
		self.lock.release()
		return data
	def getMetaDataCount(self):
		self.lock.acquire()
		count = self.metadata_count
		self.lock.release()
		return count
	def getOdomData(self, force = False):
		self.lock.acquire()
		#if (self.metadata_lastRead < self.metadata_count):
		data = self.odomdata
		if (self.metadata is not None and self.data is not None):
			map = self.data.map
			temp_x = ((-1*(map.info.origin.position.x / map.info.resolution)) + (self.odomdata.pose.pose.position.x / map.info.resolution))
			#temp_y = ((-1*(map.info.origin.position.y / map.info.resolution)) + (self.odomdata.pose.pose.position.y / map.info.resolution))
			temp_y = ((-1*(map.info.origin.position.y / map.info.resolution)) + (self.odomdata.pose.pose.position.y / map.info.resolution))
			self.locdata.x = int(temp_x)
			self.locdata.y = int(temp_y)
			self.locdata.odom = self.odomdata
			data = self.locdata
	#print(data)
		#else:
		#	data = None
		self.lock.release()
		return data
	def getOdomDataCount(self):
		self.lock.acquire()
		count = self.odomdata_count
		self.lock.release()
		return count
	def getPoseData(self, force = False):
		self.lock.acquire()
		#if (self.metadata_lastRead < self.metadata_count):
		data = self.posedata
		if (self.metadata is not None and self.data is not None):
			map = self.data.map
			self.locdata.x = self.posedata.pose.pose.position.x
			self.locdata.y = self.posedata.pose.pose.position.y
			quaternion = (
				self.posedata.pose.pose.orientation.x,
				self.posedata.pose.pose.orientation.y,
				self.posedata.pose.pose.orientation.z,
				self.posedata.pose.pose.orientation.w)
			(self.locdata.pitch,self.locdata.roll,self.locdata.yaw) = tf.transformations.euler_from_quaternion(quaternion)
			#print self.locdata.yaw
			self.locdata.pose = self.posedata
			data = self.locdata
	#print(data)
		#else:
		#	data = None
		self.lock.release()
		return data
	def getPoseDataCount(self):
		self.lock.acquire()
		count = self.posedata_count
		self.lock.release()
		return count
	def getNavigationStatus(self, force = False):
		self.lock.acquire()
		#if (self.metadata_lastRead < self.metadata_count):
		data = self.navstatusdata
		self.lock.release()
		return data
	def getNavigationStatusCount(self):
		self.lock.acquire()
		count = self.navstatusdata_count
		self.lock.release()
		return count
	def mapInitPose(self, x, y, oz, ow):
		print("Initialising Pose...")
		self.lock.acquire()
		pose = PoseWithCovarianceStamped()
		pose.header.seq = 1
		pose.header.frame_id = "map"
		pose.header.stamp = rospy.Time.now()		
		pose.pose.pose.position.x=x  #  -0.7636064291
		pose.pose.pose.position.y=y  #  0.592431366444
		pose.pose.pose.position.z=0
		pose.pose.covariance=[0.25, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.25, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.06853891945200942]
		pose.pose.pose.orientation.z=oz #  0.0134008839356
		pose.pose.pose.orientation.w=ow  #  0.999910204123
		rospy.loginfo(pose)
		self.mapInitPub.publish(pose)
		self.lock.release()
	def mapNavigateTo(self, x, y, oz, ow):
		print("Received navigate to command: (" + str(x) + ","+str(y)+")")
		self.lock.acquire()
		pose = PoseStamped()
		pose.header.seq = 1
		pose.header.frame_id = "map"
		pose.header.stamp = rospy.Time.now()		
		pose.pose.position.x=x  #  -0.7636064291
		pose.pose.position.y=y  #  0.592431366444
		pose.pose.position.z=0
		pose.pose.orientation.z=oz #  0.0134008839356
		pose.pose.orientation.w=ow  #  0.999910204123
		rospy.loginfo(pose)
		self.mapNavigatePub.publish(pose)
		self.currentlynavigating = True
		self.lock.release()
	def MapCallback(self,data):
		#print("Got Laptop")
		self.lock.acquire()
		self.data.setData(data)
		self.count += 1
		self.lock.release()
	def MapMetaDataCallback(self,data):
		#print("Got Metadata")
		self.lock.acquire()
		self.metadata = data
		self.metadata_count += 1
		self.lock.release()
	def OdomCallback(self,data):
		#print("Got Odometry")
		self.lock.acquire()
		self.odomdata = data
		self.odomdata_count += 1
		self.lock.release()
	def PoseCallback(self,data):
		#print("Got Pose")
		self.lock.acquire()
		self.posedata = data
		self.posedata_count += 1
		self.lock.release()
	def NavigationCallback(self,data):
		#print("Got Navigation status")
		self.lock.acquire()
		self.navstatusdata = data
		self.navstatusdata_count += 1
		
		# Get list of statuses
		# For each check ID
		for status in data.status_list:
			id = status.goal_id.id
			state = status.status
			state_info = status.text
			# If ID doesn't exist in navigationTasks
			if id not in self.navigationTasks:
				# Add it
				self.navigationTasks[id] = NavigationStatus(status)
				self.navigationTasks[id].complete = False
				# If status = ongoing
				if state == 1:
					print("Got Navigation starting confirmation, id " + str(id))
					# Post message confirming task
					if (self.api is not None):
						msg = cmsdk2.DataMessage()
						self.api.postOutputMessage("NavigateConfirm", msg)
				# If status = success
				elif state == 3:
					if (self.api is not None):
						print("Got unknown Navigation success confirmation, id " + str(id))
						msg = cmsdk2.DataMessage()
						self.api.postOutputMessage("NavigateConfirm", msg)
						msg = cmsdk2.DataMessage()
						self.api.postOutputMessage("NavigateSuccess", msg)
					# Mark task as complete
					self.navigationTasks[id].complete = True
					self.currentlynavigating = False
				else:
				# If status = failed
					if (self.api is not None):
						print("Got unknown Navigation failure confirmation, id " + str(id))
						msg = cmsdk2.DataMessage()
						self.api.postOutputMessage("NavigateConfirm", msg)
						msg = cmsdk2.DataMessage()
						self.api.postOutputMessage("NavigateFailed", msg)
					# Mark task as complete
					self.navigationTasks[id].complete = True
					self.currentlynavigating = False
			else:
				# Else if ID does exist in navigationTasks and is complete
				# Update timestamp
				self.navigationTasks[id].lastUpdated = datetime.datetime.now()
				if self.navigationTasks[id].complete:
					# Ignore
					self.navigationTasks[id].lastUpdated = datetime.datetime.now()
				# Else if ID does exist in navigationTasks and is not complete
				else:
					# If status = ongoing
					self.navigationTasks[id].data = status;
					if status.status == 1:
						# check for timeout
						elapsed = datetime.datetime.now() - self.navigationTasks[id].created
						#print("Got ongoing Navigation status "+str(status.status)+", id " + str(id) + " - check for timeout " + str(elapsed.total_seconds()) + " > " + str(self.navtimeout) )
						if elapsed.total_seconds() > self.navtimeout:
							if (self.api is not None):
								msg = cmsdk2.DataMessage()
								self.api.postOutputMessage("NavigateTimeout", msg)
							# Mark task as complete
							self.navigationTasks[id].complete = True
							self.currentlynavigating = False
					# If status = success
					elif status.status == 3:
						print("Got ongoing Navigation status, id " + str(id) + " - now complete!" )
						if (self.api is not None):
							msg = cmsdk2.DataMessage()
							self.api.postOutputMessage("NavigateSuccess", msg)
						# Mark task as complete
						self.navigationTasks[id].complete = True
						self.currentlynavigating = False
					# If status = failed
					else:
						print("Got ongoing Navigation status, id " + str(id) + " - now some other status: " + str(status.status) )
						if (self.api is not None):
							msg = cmsdk2.DataMessage()
							self.api.postOutputMessage("NavigateFailed", msg)
						# Mark task as complete
						self.navigationTasks[id].complete = True
						self.currentlynavigating = False
		self.lock.release()

