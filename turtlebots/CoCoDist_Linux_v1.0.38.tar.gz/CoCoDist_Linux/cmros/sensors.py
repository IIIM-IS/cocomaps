import rospy
import threading
from kobuki_msgs.msg import SensorState
from smart_battery_msgs.msg import SmartBatteryStatus #for netbook battery
from kobuki_msgs.msg import ButtonEvent
from kobuki_msgs.msg import SensorState
from sensor_msgs.msg import Image
from cmros import utils

class netbook_battery():
	def __init__(self):
		self.lock = threading.Lock()
		self.data = None
		self.count = 0
		self.lastRead = -1
		rospy.Subscriber("/laptop_charge/",SmartBatteryStatus,self.NetbookPowerEventCallback)
	def getData(self, force = False):
		self.lock.acquire()
		if (self.lastRead < self.count):
			data = self.data
		else:
			data = None
		self.lock.release()
		return data
	def getCount(self):
		self.lock.acquire()
		count = self.count
		self.lock.release()
		return count
	def NetbookPowerEventCallback(self,data):
		#print("Got Laptop")
		self.lock.acquire()
		self.data = data
		self.lock.release()

class kobuki_battery():
	def __init__(self):
		self.lock = threading.Lock()
		self.data = None
		self.count = 0
		self.lastRead = -1
		self.max_charge = 160
		rospy.Subscriber("/mobile_base/sensors/core",SensorState,self.SensorPowerEventCallback)
	def getData(self, force = False):
		self.lock.acquire()
		if (self.lastRead < self.count):
			data = self.data
		else:
			data = None
		self.lock.release()
		return data
	def getCount(self):
		self.lock.acquire()
		count = self.count
		self.lock.release()
		return count
	def SensorPowerEventCallback(self,data):
		#print("Got Laptop")
		self.lock.acquire()
		self.data = data
		self.lock.release()

class robot_camera_color():
	def __init__(self):
		self.lock = threading.Lock()
		self.color = utils.RawImage()
		self.ir = utils.RawImage()
		self.sub_once = rospy.Subscriber("/camera/rgb/image_raw",Image,self.CameraColorImageCallback)
	def getColorData(self, force = False):
		self.lock.acquire()
		data = self.color.getData()
		self.lock.release()
		return data
	def getColorCount(self):
		self.lock.acquire()
		count = self.color.serial
		self.lock.release()
		return count
	def getIRData(self, force = False):
		self.lock.acquire()
		data = self.ir.getData()
		self.lock.release()
		return data
	def getIRCount(self):
		self.lock.acquire()
		count = self.ir.serial
		self.lock.release()
		return count
	def CameraColorImageCallback(self,data):
		#print("Got Color")
		self.lock.acquire()
		self.color.setData(data)
		#if (camera_color_frame_count % 5 == 0):
		#	self.sub_once.unregister()
		#	self.sub_once = rospy.Subscriber("/camera/ir/image",Image,self.CameraIRImageCallback)
		self.lock.release()
	def CameraIRImageCallback(self,data):
		print("Got IR")
		self.lock.acquire()
		self.ir.setData(data)
		self.sub_once.unregister()
		self.sub_once = rospy.Subscriber("/camera/rgb/image_raw",Image,self.CameraColorImageCallback)
		self.lock.release()

class robot_camera_usb():
	def __init__(self):
		self.lock = threading.Lock()
		self.color = utils.RawImage()
		self.sub_once = rospy.Subscriber("/usb_cam/image_raw",Image,self.CameraUSBImageCallback)
	def getColorData(self, force = False):
		self.lock.acquire()
		data = self.color.getData()
		self.lock.release()
		return data
	def getColorCount(self):
		self.lock.acquire()
		count = self.color.serial
		self.lock.release()
		return count
	def CameraUSBImageCallback(self,data):
		#print("Got USB Image ("+ str(data.width)+","+str(data.height)+")")
		self.lock.acquire()
		self.color.setData(data)
		self.lock.release()
		
class robot_camera_depth():
	def __init__(self):
		self.lock = threading.Lock()
		self.data = utils.RawImage()
		rospy.Subscriber("/camera/depth/image_raw",Image,self.CameraDepthImageCallback)
	def getData(self, force = False):
		self.lock.acquire()
		data = self.data.getData()
		self.lock.release()
		return data
	def getCount(self):
		self.lock.acquire()
		count = self.data.getCount()
		self.lock.release()
		return count
	def CameraDepthImageCallback(self,data):
		#print("Got Laptop")
		self.lock.acquire()
		self.data.setData(data)
		self.lock.release()

class robot_camera_registered():
	def __init__(self):
		self.lock = threading.Lock()
		self.data = utils.RawImage()
		rospy.Subscriber("/camera/depth_registered/image_raw",Image,self.CameraRegisteredImageCallback)
	def getData(self, force = False):
		self.lock.acquire()
		data = self.data.getData()
		self.lock.release()
		return data
	def getCount(self):
		self.lock.acquire()
		count = self.data.getCount()
		self.lock.release()
		return count
	def CameraRegisteredImageCallback(self,data):
		#print("Got Laptop")
		self.lock.acquire()
		self.data.setData(data)
		self.lock.release()

class kobuki_button():
	def __init__(self, callback):
		self.lock = threading.Lock()
		self.data = None
		self.count = 0
		self.lastRead = -1
		self.callback = callback
		#monitor kobuki's button events
		rospy.Subscriber("/mobile_base/events/button",ButtonEvent,self.ButtonEventCallback)
	def ButtonEventCallback(self,data):
		if ( data.state == ButtonEvent.RELEASED ):
			state = "Released"
		else:
			state = "Pressed"  
		if ( data.button == ButtonEvent.Button0 ):
			button = "Button0"
		elif ( data.button == ButtonEvent.Button1 ):
			button = "Button1"
		else:
			button = "Button2"
		if (callback is not None):
			callback(button+state, data)
