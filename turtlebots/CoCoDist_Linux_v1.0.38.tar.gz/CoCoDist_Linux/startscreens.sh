#!/bin/bash

screen -Sdm "Turtlebot" "roslaunch" "turtlebot_bringup minimal.launch"
screen -Sdm "Navigation" "roslaunch" "turtlebot_navigation amcl_demo.launch map_file:=/home/turtlebot/map_ashdown.yaml"
screen -Sdm "USBCam" "roslaunch" "usb_cam usb_cam-logitech.launch"
